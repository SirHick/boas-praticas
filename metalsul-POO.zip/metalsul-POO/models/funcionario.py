class funcionario:
    def __init__(self, nome, cpf, salario, cargo):
        self.nome = nome,
        self.cpf = cpf,
        self.salario = salario,
        self.cargo = cargo