from models.funcionario import funcionario


funcionario1 = funcionario("Carlos Silva", "12345678911", 5000, "Operador CNC")

print(funcionario1.nome)
print(funcionario1.cpf)
print(funcionario1.salario)
print(funcionario1.cargo)

funcionario2 = funcionario("Henrique Miguel", "09876543211", 3200 , "Piloto de empilhadeira")

print(funcionario2.nome)
print(funcionario2.cpf)
print(funcionario2.salario)
print(funcionario2.cargo)

funcionario3 = funcionario("Emanuel Matosso", "11223344556", 3500 , "Supervisor")

print(funcionario3.nome)
print(funcionario3.cpf)
print(funcionario3.salario)
print(funcionario3.cargo)

funcionario4 = funcionario("l", "99887766001", 32000 , "CEO")

print(funcionario4.nome)
print(funcionario4.cpf)
print(funcionario4.salario)
print(funcionario4.cargo)