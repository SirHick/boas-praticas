class Funcionario:
    def __init__(self, nome, salario):
        self.nome = nome
        self.__salario = salario

    def mostrar_dados(self):
        print(f"Funcionário: {self.nome}")
        print(f"Salário: {self.__salario}")

    def calcular_bonus(self):
        print("Salário + Bônus: ", (self.__salario * 0.10) + self.__salario)

class Gerente(Funcionario):
    def calcular_bonus(self):
        super().calcular_bonus()

class Desenvolvedor(Funcionario):
    def calcular_bonus(self):
        super().calcular_bonus()

g1 = Gerente("Sandra", 15000)
g1.mostrar_dados()
g1.calcular_bonus()

d1 = Desenvolvedor("Carlos", 6000)
d1.mostrar_dados()
d1.calcular_bonus()