#Encapsulamento

class contaBancaria:
    def __init__(self, titular, saldo):
        self.titular = titular
        self.__saldo = saldo


    def depositar(self, valor):
        if valor <= 0:
            print(f"Valor negativo ou Zero. Saldo: R${self.__saldo}")
        else:
            self.__saldo += valor
            print("Depósito realizado")

    def sacar(self, valor):
        if valor > self.__saldo:
            print(f"Valor inválido. Saldo: R${self.__saldo}")
        else:
            self.__saldo -= valor
            print("Saque realizado")

    def mostrar_info(self):
        print("*"*30)
        print(" -- INFOs do TITULAR -- ")
        print(f"Titular: {self.titular}")
        print(f"Saldo: R${self.__saldo}")
        print("*" * 30)


cb1 = contaBancaria("Joao Maria", 10000)
cb1.depositar(100)
cb1.sacar(100)
cb1.mostrar_info()