

class Carro:
    def __init__(self, marca, ano, modelo):
        self.marca = marca
        self.ano = ano
        self.modelo = modelo

    def exibir_info(self):
        print("*"*35)
        print(f"Marca: {self.marca}")
        print(f"Ano: {self.ano}")
        print(f"Modelo: {self.modelo}")
        print("*"*35)

c1 = Carro("Alfa Romeo", 2000, "Alfa Romeo 166")
c1.exibir_info()