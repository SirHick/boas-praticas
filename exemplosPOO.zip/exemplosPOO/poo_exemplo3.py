class Veiculo:
    def __init__(self, rodas):
        self.rodas = rodas

    def acelerar(self):
        print("O veículo acelerou")


class Carro(Veiculo):
    def __init__(self, marca, modelo):
        super().__init__(4)
        self.marca = marca
        self.modelo = modelo

c1 = Carro("Toyota", "Fielder")
print(c1.rodas)
c1.acelerar()