class Cachorro:
    #def __init__(self):
    def som(self):
        print("Au Au")

class Gato:
    #def __init__(self):
    def som(self):
        print("Miau Miau")

class Vaca:
    #def __init__(self):
    def som(self):
        print("Muuuuuu")

def emitir_som(animal):
    animal.som()

animais = [Cachorro(), Gato(), Vaca()]

for animal in animais:
    animal.som()